// Store your Twilio credentials securely.
// DO NOT hardcode them directly in production code.
// Consider using environment variables or a secure configuration management system.

// Replace with your actual Twilio Account SID
const String twilioAccountSid = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
// Replace with your actual Twilio Auth Token
const String twilioAuthToken = "your_auth_token";
// Replace with your actual Twilio phone number (must be purchased/verified in Twilio)
const String twilioPhoneNumber = "+15551234567";
